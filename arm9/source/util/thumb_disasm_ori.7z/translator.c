#include "translator.h"

u32 disthumbcode(u16 thumbinstr){
//coto

//Low regs
switch(thumbinstr>>11){
	//5.1
	//shift
	case((0x0|0x1|0x2) && !(0x4||0x5||0x6||0x7)): //compile time previous checking
	iprintf("AND EOR LSL rd,rs,#Imm (5.1)\n");
	break;
	
	//5.3
	//mov cmp add sub imm
	case(0x4|0x5|0x6|0x7):
	iprintf("move / cmp / add / sub IMM (5.3)\n");
	break;
	
	//5.6
	//PC relative load WORD 10-bit Imm
	case(0x9):
	iprintf("(WORD) LDR RD, [PC,#IMM] (5.6)\n");
	break;
	
	////////////////////5.9 
	//LOAD/STORE low reg with #Imm
	case(0xc):
	iprintf(" STR rd, [rs,#IMM] (5.9)\n");
	break;
	
	case(0xd): //warning: small error on arm7tdmi docs (this should be LDR, but is listed as STR) as bit 11 set is load, and unset store
	iprintf(" LDR rd, [rs,#IMM] (5.9)\n");
	break;
	
	case(0xe):
	iprintf(" STRB rd, [rs,#IMM] (5.9)\n");
	break;
	
	case(0xf):
	iprintf(" LDRB rd, [rs,#IMM] (5.9)\n");
	break;
	
	/////////////////////5.10
	//store halfword from rd to low reg rs
	case(0x10):
	iprintf(" STRH rd, [rs,#IMM] (5.10)\n");
	break;
	
	//load halfword from rs to low reg rd
	case(0x11):
	iprintf(" LDRH rd, [rs,#IMM] (5.10)\n");
	break;
	

	/////////////////////5.11
	//STR RD, [SP,#IMM]
	case(0x12):
	iprintf(" STR rd, [SP,#IMM] (5.11)\n");
	break;
	
	//LDR RD, [SP,#IMM]
	case(0x13):
	iprintf(" LDR rd, [SP,#IMM] (5.11)\n");
	break;
	
	
	/////////////////////5.12
	//add #Imm to the current PC value and load the result in rd
	case(0x14):
	iprintf(" ADD  Rd, [PC,#IMM] (5.12)\n");
	break;
	
	//add #Imm to the current SP value and load the result in rd
	case(0x15):
	iprintf(" ADD  Rd, [SP,#IMM] (5.12)\n");
	break;
	
	
	/////////////////////5.15 multiple load store
	//STMIA rd!,{Rlist}
	case(0x18):
	iprintf(" STMIA rb!,{rlist}  (5.15)\n");
	break;
	
	//LDMIA rd!,{Rlist}
	case(0x19):
	iprintf(" LDMIA rb!,{rlist}  (5.15)\n");
	break;
	
	
	//5.18 BAL (branch always) PC-Address (+/- 2048 bytes)
	//must be half-word aligned (bit 0 set to 0)
	case(0x1c):
	iprintf(" B(always) label [PC relative area]  (5.18)\n");
	break;
	
	
	///////////////5.19 long branch with link
	//The assembler splits the 23-bit two's complement half-word offset speci
	//fied by the label into two 11-bit halves, ignoring bit[0] (must be 0),
	//and creates two THUMB instructions-
	
	case(0x1e): 
	//H bit[11<0]
	//Instruction 1:
	//In the first instruction the offset field contains the upper 11 bits
	//of the target address. This is shifted left by 12 bits and added to
	//the current PC address. The resulting address is placed in LR.
	
	/*
	//(thumbinstr[0] & 0x7ff) holds upper 11 bits 
	
	LR = PC +  ((thumbinstr[0] & 0x7ff) << 12);
	
	*/
	
		iprintf(" B long branch label 1/2 bit[11<0] (5.19)\n");
		
	break;

	case(0x1f):
	
	//H bit[11<1]
	//Instruction 2:
	//In the second instruction the offset field contains an 11-bit 
	//representation lower half of the target address. This is shifted
	//by 1 bit and added to LR. LR which now contains the full 23-bit
	//address, is placed in PC, the address of the instruction following
	//the BL is placed in LR and bit[0] of LR is set.
	
	//The branch offset must take account of the prefetch operacion, which
	//causes the PC to be 1 word (4 bytes) ahead of the current instruction.
	
	/*
	//(thumbinstr[1] & 0x7ff) holds lower 11 bits
	
	LR += ((thumbinstr[1] & 0x7ff) << 1)
	PC=LR
	
	*/
		iprintf(" B long branch label 2/2 bit[11<1] (5.19)\n");
	
	
	break;
	
	

}
switch(thumbinstr>>10){
	//5.4
	//ALU OP: AND EOR LSL LSR ASR ADC SBC ROR TST NEG
	case(0x10):
	iprintf("ALU OP: AND EOR LSL rd,rd, rs (5.4)\n");
	break;
}

switch(thumbinstr>>9){
	
	//5.2
	//add
	case(0xc):
	iprintf("add rd,rs,#Imm (5.2)\n");
	break;
	
	//sub
	case(0xd):
	iprintf("sub rd,rs,#Imm (5.2)\n");
	break;
	
	/////////////////////5.7
	//STR
	case(0x28): //40dec
	iprintf("STR RD ,[RS0,RS1] (5.7)\n");
	break;
	
	case(0x2a): //42dec
	iprintf("STRB RD ,[RS0,RS1] (5.7)\n");
	break;
	//LDR
	case(0x2c): //44dec
	iprintf("LDR RD ,[RS0,RS1] (5.7)\n");
	break;
	
	case(0x2e): //46dec
	iprintf("LDRB RD ,[RS0,RS1] (5.7)\n");
	break;
	
	
	//////////////////////5.8
	//load sign-extended / halfword
	case(0x29): //41dec strh
	iprintf("STRH RD ,[RS0,RS1] (5.8)\n");
	break;
	
	case(0x2b): //43dec ldrh
	iprintf("LDRH RD ,[RS0,RS1] (5.8)\n");
	break;
	
	case(0x2d): //45dec ldsb
	iprintf("LDSB RD ,[RS0,RS1] (5.8)\n");
	break;
	
	case(0x2f): //47dec ldsh
	iprintf("LDSH RD ,[RS0,RS1] (5.8)\n");
	break;

}

switch(thumbinstr>>8){
	///////////////////////////5.14
	//b: 10110100 = PUSH {Rlist} low regs (0-7)
	case(0xB4):
	iprintf("PUSH {Rlist} (5.14)\n");
	break;
	
	//b: 10110101 = PUSH {Rlist,LR}  low regs (0-7) & LR
	case(0xB5):
	iprintf("PUSH {Rlist,LR} (5.14)\n");
	break;
	
	//b: 10111100 = POP  {Rlist} low regs (0-7)
	case(0xBC):
	iprintf("POP {Rlist} (5.14)\n");
	break;
	
	//b: 10111101 = POP  {Rlist,PC} low regs (0-7) & PC
	case(0xBD):
	iprintf("POP {Rlist,PC} (5.14)\n");
	break;
	
	
	///////////////////5.16 Conditional branch
	//b: 1101 0000 / BEQ / Branch if Z set (equal)
	case(0xd0):
	iprintf("BEQ label (5.16)\n");
	break;
	
	//b: 1101 0001 / BNE / Branch if Z clear (not equal)
	case(0xd1):
	iprintf("BNE label (5.16)\n");
	break;
	
	//b: 1101 0010 / BCS / Branch if C set (unsigned higher or same)
	case(0xd2):
	iprintf("BCS label (5.16)\n");
	break;
	
	//b: 1101 0011 / BCC / Branch if C unset (lower)
	case(0xd3):
	iprintf("BCC label (5.16)\n");
	break;
	
	//b: 1101 0100 / BMI / Branch if N set (negative)
	case(0xd4):
	iprintf("BMI label (5.16)\n");
	break;
	
	//b: 1101 0101 / BPL / Branch if N clear (positive or zero)
	case(0xd5):
	iprintf("BPL label (5.16)\n");
	break;
	
	//b: 1101 0110 / BVS / Branch if V set (overflow)
	case(0xd6):
	iprintf("BVS label (5.16)\n");
	break;
	
	//b: 1101 0111 / BVC / Branch if V unset (no overflow)
	case(0xd7):
	iprintf("BVC label (5.16)\n");
	break;
	
	//b: 1101 1000 / BHI / Branch if C set and Z clear (unsigned higher)
	case(0xd8):
	iprintf("BHI label (5.16)\n");
	break;
	
	//b: 1101 1001 / BHI / Branch if C clr and Z Set (lower or same [zero included])
	case(0xd9):
	iprintf("BLS label (5.16)\n");
	break;
	
	//b: 1101 1010 / BGE / Branch if N set and V set, or N clear and V clear
	case(0xda):
	iprintf("BGE label (5.16)\n");
	break;
	
	//b: 1101 1011 / BLT / Branch if N set and V clear, or N clear and V set
	case(0xdb):
	iprintf("BLT label (5.16)\n");
	break;
	
	//b: 1101 1100 / BGT / Branch if Z clear, and either N set and V set or N clear and V clear
	case(0xdc):
	iprintf("BGT label (5.16)\n");
	break;
	
	//b: 1101 1101 / BLE / Branch if Z set, or N set and V clear, or N clear and V set (less than or equal)
	case(0xdd):
	iprintf("BLE label (5.16)\n");
	break;
	
	

	//5.17 SWI software interrupt changes into ARM mode and uses SVC mode/stack (SWI 14)
	case(0xDF): 
	iprintf("SWI #Value8 (5.17)\n");
	break;


	default:
	iprintf("unknown OP! %x\n",thumbinstr>>9); //latest debug
	break;
	
}


switch(thumbinstr>>7){
	////////////////////////////5.13
	case(0x160): //dec 352 : add bit[9] depth #IMM to the SP, positive offset
	iprintf("ADD SP,#Imm (5.13)\n");
	break;
	
	case(0x161): //dec 353 : add bit[9] depth #IMM to the SP, negative offset
	iprintf("ADD SP,#-Imm (5.13)\n");
	break;
	
}

switch(thumbinstr>>6){
	
	//high regs <-> low regs
	////////////////////////////5.5
	//ADD
	case(0x111):
	iprintf("ADD rd,hs (5.5)\n");
	break;

	case(0x112):
	iprintf("ADD hd,rs (5.5)\n");
	break;
	
	case(0x113):
	iprintf("ADD hd,hs (5.5)\n");
	break;
	//CMP
	case(0x115):
	iprintf("CMP rd,hs (5.5)\n");
	break;
	
	case(0x116):
	iprintf("CMP hd,rs (5.5)\n");
	break;
	
	case(0x117):
	iprintf("CMP hd,hs (5.5)\n");
	break;
	//MOV
	case(0x119):
	iprintf("MOV rd,hs (5.5)\n");
	break;
	
	case(0x11a):
	iprintf("MOV Hd,Rs (5.5)\n");
	break;
	
	case(0x11b):
	iprintf("MOV hd,hs (5.5)\n");
	break;
	//BX
	case(0x11c):
	iprintf("BX RS (5.5)\n"); //low
	break;
	
	case(0x11D):
	iprintf("BX HS (5.5)\n"); //h
	break;
	
	
}

return thumbinstr;
}