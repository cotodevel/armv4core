#include <nds/ndstypes.h>
#include <nds.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>//BRK(); SBRK();
#include <nds/ndstypes.h>
#include <nds/memory.h>
//#include <nds/bios.h>
#include <nds/system.h>

//tested
//0x008b lsl rd,rs,#Imm (5.1)
//0x1841 adds rd,rs,rn / 0x1a41 subs rd,rs,rn / #Imm (5.2)
//0x3c01 subs r4,#1 (5.3) 
//0x40da lsrs rd,rs (5.4)
//0x4770 bx lr / 0x449c add ip,r3 (5.5)
//0x4e23 LDR RD,[PC,#Imm] (5.6)
//0x5158 str r0,[r3,r5] / 0x58f8 ldr r0,[r7,r3] (5.7)
//0x5e94 ldsh r0,[r3,r4] (5.8)
//0x69aa ldr r2,[r5,#24] / 0x601a str r2,[r3,#0] (5.9)
//0x87DB ldrh r3,[r2,#3] // 0x87DB strh r3,[r2,#3] (5.10)
//0x97FF str rd,[sp,#Imm] / 0x9FFF ldr rd,[sp,#Imm] (5.11)
//0xa2e1 rd,[pc,#Imm] / 0xaae1 add rd,[sp,#Imm] (5.12)
//0xb01a add sp,#imm / 0xb09a add sp,#-imm(5.13)
//0xb4ff push {rlist} / 0xb5ff push {Rlist,LR} / 0xbcff pop {Rlist} / 0xbdff pop {Rlist,PC}
//0xc7ff stmia rb!,{rlist} / 0xcfff ldmia rb!,{rlist} (5.15)

//(5.16)
//0xd0ff BEQ label / 0xd1ff BNE label / 0xd2ff BCS label / 0xd3ff BCC label 
//0xd4ff BMI label / 0xd5ff BPL label / 0xd6ff BVS label / 0xd7ff BVC label
//0xd8ff BHI label / 0xd9ff BLS label / 0xdaff BGE label / 0xdbff BLT label
//0xdcff BGT label / 0xddff BLE label

//0xdfff swi #value8 (5.17)
//0xe7ff b(al) PC-relative area (5.18)
//0xf7ff 1/2 long branch
//0xffff 2/2 long branch (5.19)


#ifdef __cplusplus
extern "C"{
#endif

u32 disthumbcode(u16);

#ifdef __cplusplus
}
#endif